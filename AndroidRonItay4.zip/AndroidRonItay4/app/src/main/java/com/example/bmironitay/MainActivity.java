package com.example.bmironitay;
//Exercise 4
//Ron Dahan ID 206765190, rondahan124@gmail.com
//Itay Cohen ID 207450115,itayco227@gmail.com
//Second year, Computer Science Department- Ashqelon College
//================================================
//
//Assignment:
//Writing an application in android studio that calculates  the physical condition,
//weight and ideal weight of a human, when gender, height
//physique, etc. are known according to the exercise requirement.
//
//Algorithm:
//Calculation of physical condition - weight is by the BMI Body
//Mass Index in accordance with the following formula, for both
//men and women:  BMI = W / H^2
//and the ideal weight according to the formula:
//ideal weight = (height - 100 + (age / 10)) * 0.9 * slimness.
//
//uses:
//class 3
//layout 3
//one for the main
//one for the opening page
//one for after u hit the buttom calclate
//in the drawable file png 8
//male,female,plus,minus,signs
//xml 7
//all the ui design are some from youtube and some from github
//after the ui design we connected the buttoms with Listener
//for the bmi range we used if statments and to summon it we call it by id right below the bmi

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {


    TextView mcurrentheight;
    TextView mcurrentweight,mcurrentage;
    ImageView mincrementage,mdecrementage,mincrementweight,mdecrementweight;
    SeekBar mseekbarforheight;
    Button mcalculatebmi;
    RelativeLayout mmale,mfemale;

    int intweight=55;
    int intage=22;
    int currentprogress;
    String mintprogress="170";
    String typerofuser="0";
    String weight2="55";
    String age2="22";

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Objects.requireNonNull(getSupportActionBar()).hide();
        mcurrentage=findViewById(R.id.currentage);
        mcurrentweight=findViewById(R.id.currentweight);
        mcurrentheight=findViewById(R.id.currentheight);
        mincrementage=findViewById(R.id.incrementage);
        mdecrementage=findViewById(R.id.decrementage);
        mincrementweight=findViewById(R.id.incremetweight);
        mdecrementweight=findViewById(R.id.decrementweight);
        mcalculatebmi=findViewById(R.id.calculatebmi);
        mseekbarforheight=findViewById(R.id.seekbarforheight);
        mmale=findViewById(R.id.male);
        mfemale=findViewById(R.id.female);



        mmale.setOnClickListener(v -> {
            mmale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.malefemalefocus));
            mfemale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.malefemalenotfocus));
            typerofuser="Male";

        });


        mfemale.setOnClickListener(v -> {
            mfemale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.malefemalefocus));
            mmale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.malefemalenotfocus));
            typerofuser="Female";
        });

        mseekbarforheight.setMax(300);
        mseekbarforheight.setProgress(170);
        mseekbarforheight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                currentprogress=progress;
                mintprogress=String.valueOf(currentprogress);
                mcurrentheight.setText(mintprogress);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        mincrementweight.setOnClickListener(v -> {
            intweight=intweight+1;
            weight2=String.valueOf(intweight);
            mcurrentweight.setText(weight2);
        });

        mincrementage.setOnClickListener(v -> {
            intage=intage+1;
            age2=String.valueOf(intage);
            mcurrentage.setText(age2);
        });


        mdecrementage.setOnClickListener(v -> {
            intage=intage-1;
            age2=String.valueOf(intage);
            mcurrentage.setText(age2);
        });


        mdecrementweight.setOnClickListener(v -> {

            intweight=intweight-1;
            weight2=String.valueOf(intweight);
            mcurrentweight.setText(weight2);
        });



        mcalculatebmi.setOnClickListener(v -> {

            if(typerofuser.equals("0"))
            {
                Toast.makeText(getApplicationContext(),"Select Your Gender First",Toast.LENGTH_SHORT).show();
            }
            else if(mintprogress.equals("0"))
            {
                Toast.makeText(getApplicationContext(),"Select Your Height First",Toast.LENGTH_SHORT).show();
            }
            else if(intage==0 || intage<0)
            {
                Toast.makeText(getApplicationContext(),"Age is Incorrect",Toast.LENGTH_SHORT).show();
            }

            else if(intweight==0|| intweight<0)
            {
                Toast.makeText(getApplicationContext(),"Weight Is Incorrect",Toast.LENGTH_SHORT).show();
            }
            else {

                Intent intent = new Intent(MainActivity.this, bmiactive.class);
                intent.putExtra("gender", typerofuser);
                intent.putExtra("height", mintprogress);
                intent.putExtra("weight", weight2);
                intent.putExtra("age", age2);
                startActivity(intent);

            }


        });


    }
}